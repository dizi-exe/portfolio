import type { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Dwi Cahyo — Digital Marketing',
    short_name: 'Dwi Cahyo',
    description:
      'Dwi Cahyo is a Digital Marketing Executive building campaigns, content, and the automation and reporting systems behind them.',
    start_url: '/',
    display: 'standalone',
    background_color: '#131313',
    theme_color: '#131313',
    icons: [
      { src: '/icon.svg', sizes: 'any', type: 'image/svg+xml' },
      { src: '/apple-icon.png', sizes: '180x180', type: 'image/png' },
    ],
  }
}
