import { ExperienceShowcase } from '@/components/site/experience-showcase'
import { Dock } from '@/components/site/dock'
import { Contact } from '@/components/site/contact'
export const metadata={"title":"GetFound | Dwi Cahyo","description":"Local SEO, client delivery and Google Business Profile work by Dwi Cahyo.","alternates":{"canonical":"https://dwicahyo.vercel.app/work/getfound"},"openGraph":{"title":"GetFound | Dwi Cahyo","description":"Local SEO, client delivery and Google Business Profile work by Dwi Cahyo.","url":"https://dwicahyo.vercel.app/work/getfound","images":["/portraits/ALE02687.webp"]},"twitter":{"card":"summary_large_image","title":"GetFound | Dwi Cahyo","description":"Local SEO, client delivery and Google Business Profile work by Dwi Cahyo.","images":["/portraits/ALE02687.webp"]}}
export default function Page(){return <><main className="company-page"><ExperienceShowcase initialCompany="getfound"/></main><Contact/><Dock/></>}
