import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Plus_Jakarta_Sans } from 'next/font/google'
import { ThemeProvider } from '@/components/theme-provider'
import './globals.css'
import 'leaflet/dist/leaflet.css'
import './refinements.css'

const sans = Plus_Jakarta_Sans({ subsets: ['latin'], variable: '--font-jakarta' })

export const metadata: Metadata = {
  title: 'Dwi Cahyo | Digital Marketing & Creative Production',
  metadataBase: new URL('https://dwicahyo.vercel.app'),
  openGraph: { title: 'Dwi Cahyo | Digital Marketing & Creative Production', description: 'Campaigns, creative production and marketing workflows by Dwi Cahyo.', url: 'https://dwicahyo.vercel.app', images: [{ url: '/dwi-cahyo-social-r34.jpg', width: 1200, height: 630, alt: 'Dwi Cahyo — Digital Marketing and Creative Production' }] },
  description:
    'Dwi Cahyo is a Digital Marketing Executive building campaigns, content, and the automation and reporting systems behind them.',
  twitter: { card: 'summary_large_image', images: ['/dwi-cahyo-social-r34.jpg'] },
  applicationName: 'Dwi Cahyo',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  colorScheme: 'dark light',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f4f3ef' },
    { media: '(prefers-color-scheme: dark)', color: '#131313' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={sans.variable}>
      <body className="font-sans antialiased">
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} disableTransitionOnChange>
          <div className="ambient-background" aria-hidden="true"><span/><span/><span/></div>
          {children}
        </ThemeProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
