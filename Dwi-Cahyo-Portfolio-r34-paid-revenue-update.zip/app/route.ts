import { homepageDocument } from '@/lib/homepage-document'
export const dynamic = 'force-static'
export function GET() { return new Response(homepageDocument, { headers: { 'Content-Type': 'text/html; charset=utf-8' } }) }
