'use client'
import { useRef, type ReactNode, type PointerEvent } from 'react'
export function TiltCard({ children, className = '', border = false, focusable = false }: { children: ReactNode; className?: string; border?: boolean; focusable?: boolean }) {
  const ref = useRef<HTMLDivElement>(null)
  function move(event: PointerEvent<HTMLDivElement>) {
    if (event.pointerType !== 'mouse' || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const node = ref.current
    if (!node) return
    const rect = node.getBoundingClientRect()
    const x = (event.clientX - rect.left) / rect.width
    const y = (event.clientY - rect.top) / rect.height
    node.style.setProperty('--tilt-x', `${(0.5 - y) * 5}deg`)
    node.style.setProperty('--tilt-y', `${(x - 0.5) * 5}deg`)
    node.style.setProperty('--spot-x', `${x * 100}%`)
    node.style.setProperty('--spot-y', `${y * 100}%`)
  }
  function reset() {
    ref.current?.style.setProperty('--tilt-x', '0deg')
    ref.current?.style.setProperty('--tilt-y', '0deg')
  }
  return <div ref={ref} tabIndex={focusable ? 0 : undefined} onPointerMove={move} onPointerLeave={reset} className={`liquid-card ${border ? 'quiet-border' : ''} ${className}`}>{children}</div>
}
