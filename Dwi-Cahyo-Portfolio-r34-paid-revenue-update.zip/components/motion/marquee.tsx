'use client'
import { useState } from 'react'
import { Pause, Play } from 'lucide-react'
import { useReducedMotion } from './use-reduced-motion'
const words = ['Strategy', 'Creative production', 'Curiosity', 'Music', 'Storytelling']
export function Marquee() {
  const [paused, setPaused] = useState(false)
  const reduced = useReducedMotion()
  return <section className={`type-marquee ${paused || reduced ? 'is-paused' : ''}`} aria-label="Strategy, creative production, curiosity, music and storytelling">
    <div className="marquee-track" aria-hidden="true">{[0, 1].map(copy => <div className="marquee-copy" key={copy}>{words.map(word => <span key={word}>{word}<b>✳</b></span>)}</div>)}</div>
    <button type="button" className="motion-switch" onClick={() => setPaused(!paused)} aria-label={paused ? 'Play moving text' : 'Pause moving text'} aria-pressed={paused} disabled={reduced}>{paused || reduced ? <Play size={14} /> : <Pause size={14} />}</button>
  </section>
}
