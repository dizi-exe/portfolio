'use client'
import { useEffect, useRef, useState, type CSSProperties } from 'react'
export function RevealCopy({text,className=''}:{text:string;className?:string}){
 const ref=useRef<HTMLSpanElement>(null);const[visible,setVisible]=useState(false)
 useEffect(()=>{const el=ref.current;if(!el)return;if(matchMedia('(prefers-reduced-motion: reduce)').matches||!('IntersectionObserver' in window)){setVisible(true);return}const observer=new IntersectionObserver(([entry])=>{if(entry.isIntersecting){setVisible(true);observer.disconnect()}},{threshold:.15});observer.observe(el);return()=>observer.disconnect()},[])
 return <span ref={ref} className={`reveal-copy ${visible?'is-visible':''} ${className}`} aria-label={text}>{text.split(' ').map((word,i)=><span aria-hidden="true" className="word-mask" key={i}><span style={{'--word-delay':`${Math.min(i,15)*45}ms`} as CSSProperties}>{word}&nbsp;</span></span>)}</span>
}
