'use client'
import { useEffect, useRef, type ReactNode } from 'react'
export function RevealGroup({children,className=''}:{children:ReactNode;className?:string}){
 const ref=useRef<HTMLDivElement>(null)
 useEffect(()=>{const root=ref.current;if(!root||matchMedia('(prefers-reduced-motion: reduce)').matches)return
 const nodes=root.querySelectorAll<HTMLElement>('[data-reveal]');if(!nodes.length)return
 const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-revealed');observer.unobserve(entry.target)}})},{threshold:.08,rootMargin:'0px 0px -24px 0px'})
 root.classList.add('motion-ready');nodes.forEach((node,i)=>{node.style.setProperty('--reveal-delay',`${i%3*65}ms`);observer.observe(node)})
 return()=>{observer.disconnect();root.classList.remove('motion-ready')}
 },[])
 return <div className={className} ref={ref}>{children}</div>
}
