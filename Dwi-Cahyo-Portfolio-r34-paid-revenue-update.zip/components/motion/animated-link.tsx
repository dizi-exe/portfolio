import { ArrowUpRight } from 'lucide-react'
import type { ReactNode } from 'react'
export function AnimatedLink({ href, children, external = false, className = '' }: { href: string; children: ReactNode; external?: boolean; className?: string }) {
  return <a href={href} className={`sweep-button ${className}`} {...(external ? { target: '_blank', rel: 'noreferrer' } : {})}><span>{children}</span><ArrowUpRight size={16} aria-hidden="true" /></a>
}
