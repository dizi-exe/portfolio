'use client'
import { EditorialGallery } from './editorial-gallery'
const images=[
 {src:'/photos/sapphire-interior.webp',alt:'Sapphire Ballroom interior',label:'Sapphire Ballroom · Space & light'},
 {src:'/photos/sapphire-tables.webp',alt:'Sapphire Ballroom prepared with round tables',label:'Sapphire Ballroom · Ready to gather'},
 {src:'/photos/dessert-orchid.webp',alt:'Dessert table with orchid details',label:'Dessert table · Details in bloom'},
 {src:'/photos/sushi-detail.webp',alt:'Close-up of sushi presentation',label:'Sushi · Food details'},
 {src:'/photos/sate-maranggi.webp',alt:'Sate Maranggi served with rice and accompaniments',label:'Sate Maranggi · Food photography'},
 {src:'/photos/orange-coffee.webp',alt:'Orange Coffee photographed for the hotel dining promotion',label:'Orange Coffee · Beverage photography'},
 {src:'/photos/IMG_1061.webp',alt:'Sip Society guests by the pool at The Grove Suites by Grand Aston',label:'Sip Society · Poolside moments'},
 {src:'/photos/grooviest-cake-detail.webp',alt:'Grooviest cake with chocolate plaque and floral details',label:'Grooviest · Product details'},
 {src:'/photos/grooviest-whole-cake.webp',alt:'Whole Grooviest cake photographed on a marble table',label:'Grooviest · Whole cake'},
 {src:'/photos/IMG_1092.webp',alt:'Fresh pizza photographed for the Sip Society dining campaign',label:'Sip Society · Food, in focus'},
]
export function PhotoStack(){return <section className="photo-editorial"><div className="library-intro"><div><p className="eyebrow">THE GROVE SUITES BY GRAND ASTON / PHOTOGRAPHY</p><h3>People. Places. Details.</h3></div><p>From a ballroom before guests arrive to the finishing details on a plate. Selected frames from hotel content shoots.</p></div><EditorialGallery variant="photo" label="Hotel photography" items={images.map(item=>({src:item.src,alt:item.alt,title:item.label.split(' · ')[0],detail:item.label.split(' · ')[1]}))}/></section>}
