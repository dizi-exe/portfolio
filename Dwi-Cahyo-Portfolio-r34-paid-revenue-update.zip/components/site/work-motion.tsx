'use client'
import {useEffect} from 'react'
export function WorkMotion({chapter}:{chapter:string}){
 useEffect(()=>{if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;const root=document.getElementById('work-content');if(!root)return;const observer=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){e.target.animate([{opacity:.35,transform:'translateY(20px)'},{opacity:1,transform:'translateY(0)'}],{duration:650,easing:'cubic-bezier(.2,.7,.2,1)'});observer.unobserve(e.target)}})},{threshold:.1});root.querySelectorAll('.library-intro,.case-heading,.bahana-opening,.bahana-chapter>.eyebrow,.bahana-transition,.bahana-writing-grid>article,.scope-visual,.gbp-editorial-post,.story-sequence>section').forEach(el=>observer.observe(el));return()=>observer.disconnect()},[chapter]);return null
}
