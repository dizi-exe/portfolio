import { LocalSeoScope } from './local-seo-scope'
import { TiltCard } from '@/components/motion/tilt-card'
import { seo } from '@/lib/content'
import { SectionHeader } from './section-header'

export function SeoProjects() {
  return (
    <section aria-labelledby="seo-title" id="seo" className="px-5 py-20 md:px-10 md:py-32">
      <div className="mx-auto max-w-6xl">
        <SectionHeader id="seo-title" index="03" label="Client delivery" title="Help people find the right business." />

        <div className="mt-14 grid gap-10 md:mt-20 md:grid-cols-12">
          <div className="md:col-span-5">
            <p className="font-mono text-xs text-muted-foreground">
              {seo.company} · {seo.city}
            </p>
            <p className="mt-2 text-xl font-semibold">{seo.role}</p>
            <p className="font-mono text-xs text-muted-foreground">{seo.period}</p>
            <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
              {seo.intro.before}
              <strong className="font-semibold text-foreground">{seo.intro.accounts}</strong>
              {seo.intro.middle}
              <strong className="font-semibold text-foreground">{seo.intro.strategy}</strong>
              {seo.intro.after}
            </p>
          </div>

          <TiltCard focusable className="seo-glass md:col-span-7 p-6 md:p-10">
            <p className="font-mono text-[11px] tracking-[0.2em] uppercase opacity-60">{seo.highlight.label}</p>
            <h3 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">{seo.highlight.title}</h3>
            <dl className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-3">
              {seo.highlight.metrics.map((metric) => (
                <div key={metric.label} className="flex flex-col-reverse border-t border-foreground/20 pt-4">
                  <dt className="mt-1 text-sm opacity-70">{metric.label}</dt>
                  <dd className="text-4xl font-bold tracking-tighter text-primary tabular-nums">{metric.value}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-10 text-sm leading-relaxed opacity-70">{seo.highlight.note}</p>
          </TiltCard>
        </div>

        <LocalSeoScope/>
        <ul className="mt-16 grid gap-px overflow-hidden rounded-2xl border border-border bg-border md:grid-cols-3">
          {seo.pillars.map((pillar, i) => (
            <li key={pillar.title} className="bg-background p-6 md:p-8">
              <p className="font-mono text-xs text-primary">{String(i + 1).padStart(2, '0')}</p>
              <h3 className="mt-3 text-lg font-semibold">{pillar.title}</h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">
                {pillar.before}
                <strong className="font-semibold text-foreground">{pillar.emphasis}</strong>
                {pillar.after}
              </p>
            </li>
          ))}
        </ul>

        <div className="mt-6 flex flex-col gap-2 rounded-2xl border border-dashed border-border p-6 md:flex-row md:items-center md:justify-between md:p-8">
          <h3 className="text-lg font-semibold">{seo.articles.title}</h3>
          <p className="text-muted-foreground">{seo.articles.description}</p>
        </div>
      </div>
    </section>
  )
}
