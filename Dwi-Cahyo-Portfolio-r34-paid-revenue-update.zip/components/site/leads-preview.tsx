import data from '@/lib/leads-evidence.json'
import { RevealGroup } from '@/components/motion/reveal-group'
import { MessageCircle, Users, CircleCheck, ArrowRight } from 'lucide-react'

const paidRevenue = new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(data.paidRevenue / 1_000_000)

export function LeadsPreview() {
  return (
    <section className="leads-story" id="leads">
      <div className="leads-case revenue-highlight">
        <div>
          <p className="eyebrow">LEADS TRACKER / CAMPAIGN FOLLOW-THROUGH</p>
          <h3>An inquiry is<br />the beginning.</h3>
          <p>I use a <strong>shared leads tracker</strong> to connect the first message, team follow-up and recorded booking value.</p>
        </div>
        <div className="revenue-total">
          <span>Paid revenue</span>
          <strong>≈ Rp{paidRevenue}M</strong>
          <p>{data.period}</p>
          <small>Rounded from the dashboard. Paid bookings across tracked sources; not attributed to a single campaign.</small>
        </div>
      </div>
      <RevealGroup className="lead-journey">
        {[
          { Icon: MessageCircle, title: 'Capture the inquiry', copy: 'Give the request a record the team can follow.' },
          { Icon: Users, title: 'Keep follow-up visible', copy: 'Connect the inquiry with the team handling it.' },
          { Icon: CircleCheck, title: 'Record the outcome', copy: 'Track booking value when the outcome is recorded.' },
        ].map(({ Icon, title, copy }, i) => (
          <article data-reveal key={title}>
            <span className="journey-icon"><Icon size={22} /></span>
            <small>0{i + 1}</small><h4>{title}</h4><p>{copy}</p>
            {i < 2 && <ArrowRight className="journey-connector" size={20} />}
          </article>
        ))}
      </RevealGroup>
    </section>
  )
}
