'use client'
import { useMemo, useState } from 'react'
import { ArrowUpRight, Search } from 'lucide-react'
const tracks = [
  { title: 'Pain.fm', artist: 'Contemporary Art', href: 'https://www.musixmatch.com/lyrics/Contemporary-Art/Pain-fm', action: 'Lyrics', source: 'Musixmatch' },
  { title: 'Hopeless Romantic', artist: 'Contemporary Art', href: 'https://www.shazam.com/song/1646004660/hopeless-romantic-feat-adtria-fachri', action: 'Lyrics', source: 'Shazam' },
  { title: 'Flare', artist: 'Contemporary Art', href: 'https://www.shazam.com/song/1646004656/flare', action: 'Lyrics', source: 'Shazam' },
  { title: 'Forever Nothing', artist: 'Contemporary Art', href: 'https://www.shazam.com/song/1646004659/forever-nothing', action: 'Lyrics', source: 'Shazam' },
  { title: 'Life Sucks, Good Night', artist: 'Contemporary Art', href: 'https://www.shazam.com/song/1743451730/life-sucks-good-night', action: 'Lyrics', source: 'Shazam' },
  { title: 'Sincere Wonder', artist: 'Teashells', href: 'https://music.amazon.com/tracks/B0GR2661JZ', action: 'Track', source: 'Amazon Music' },
  { title: 'Krayon', artist: 'Meltz', href: 'https://outtasightrecords.bandcamp.com/track/krayon', action: 'Lyrics', source: 'Bandcamp' },
  { title: 'LIGHT', artist: 'CLOBAZIPLINE', href: 'https://open.spotify.com/track/7hRalU1jCNDqo332NoAJ4N', action: 'Track', source: 'Spotify' },
  { title: 'TRY', artist: 'CLOBAZIPLINE', href: 'https://open.spotify.com/track/4NKtXxockBISYeCoXmEtfU', action: 'Track', source: 'Spotify' },
  { title: 'Memento', artist: 'Contemporary Art', href: 'https://www.shazam.com/song/1798997342/memento-feat-ryan-shidqi', action: 'Lyrics', source: 'Shazam' },
  { title: 'A Love Song, I Guess?', artist: 'Contemporary Art', href: 'https://www.shazam.com/song/1608904095/a-love-song-i-guess', action: 'Lyrics', source: 'Shazam' },
]
export function MusicLibrary() {
  const [artist, setArtist] = useState('All')
  const [query, setQuery] = useState('')
  const visible = useMemo(() => tracks.filter(track => (artist === 'All' || track.artist === artist) && `${track.title} ${track.artist}`.toLowerCase().includes(query.toLowerCase())), [artist, query])
  return <div className="music-library"><div className="library-controls"><div className="library-filters" aria-label="Filter lyric credits by artist">{['All', 'Contemporary Art', 'Teashells', 'Meltz', 'CLOBAZIPLINE'].map(name => <button type="button" key={name} aria-pressed={artist === name} onClick={() => setArtist(name)}>{name}</button>)}</div><label className="library-search"><Search size={15} /><span className="sr-only">Search songs</span><input type="search" placeholder="Search the library" value={query} onChange={e => setQuery(e.target.value)} /></label></div>
    <div className="track-header"><span>#</span><span>Title / Artist</span><span>Explore</span></div><ol className="track-list">{visible.map(track => <li key={track.title}><span className="track-number">{String(tracks.indexOf(track) + 1).padStart(2, '0')}</span><div><h3>{track.title}{track.title === 'Pain.fm' && <span className="track-new">NEW</span>}</h3><p>{track.artist}</p></div><a href={track.href} target="_blank" rel="noreferrer" aria-label={`${track.action} for ${track.title} on ${track.source}`}><span>{track.action}<small>{track.source}</small></span><ArrowUpRight size={14} /></a></li>)}</ol>{visible.length === 0 && <p className="library-empty">No songs match that search. Try another title or artist.</p>}<p className="library-count" aria-live="polite">{visible.length} of {tracks.length} selected lyric credits</p>
  </div>
}
