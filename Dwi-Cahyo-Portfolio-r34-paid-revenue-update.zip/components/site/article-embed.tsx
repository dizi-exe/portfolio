'use client'
import { useState } from 'react'
import { ArrowUpRight, FileText } from 'lucide-react'
const url = 'https://www.astonhotelsinternational.com/en/blog/grclc-sip-society-poolside-ayce-jakarta'
const originalImage = 'https://images.archipelagohotels.com/astoninternational/Images/v1/TheGroveSuitesbyGrandAston/Others/SipSocietySat-Sun.png?d=3200x2134&imagetype=webp&quality=80'
export function ArticleEmbed() {
  const [imageUnavailable, setImageUnavailable] = useState(false)
  return (
    <a href={url} target="_blank" rel="noreferrer" className="article-original article-published" aria-label="Read Poolside AYCE Jakarta: Sip Society Every Weekend on the hotel website">
      <img src={imageUnavailable ? '/canva-2-800x476.webp' : originalImage}
        alt="Sip Society, as published on the hotel website"
        loading="lazy" onError={() => setImageUnavailable(true)} />
      <div className="article-caption">
        <p className="article-byline">ASTON HOTELS · 13 JUL 2026</p>
        <h4>Poolside AYCE Jakarta: Sip Society Every Weekend</h4>
        <p>Published by The Grove Suites by Grand Aston</p>
        <span><FileText size={15} /> Read the article <ArrowUpRight size={16} /></span>
      </div>
    </a>
  )
}
