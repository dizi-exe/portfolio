'use client'
import { useState } from 'react'
import { ArrowUpRight, Play } from 'lucide-react'
export function YouTubeEmbed({ id, title, thumbnail }: { id: string; title: string; thumbnail: string }) {
  const [playing, setPlaying] = useState(false)
  return <div className="youtube-media"><div className="youtube-stage">{playing ? <iframe src={`https://www.youtube-nocookie.com/embed/${id}?autoplay=1`} title={title} allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" /> : <button type="button" aria-label={`Play ${title}`} onClick={() => setPlaying(true)}><img src={thumbnail} alt={`${title}, original YouTube thumbnail`} loading="lazy" /><span><Play size={24} fill="currentColor" /></span></button>}</div><a href={`https://www.youtube.com/watch?v=${id}`} target="_blank" rel="noreferrer" className="embed-original">Watch on YouTube <ArrowUpRight size={13} /></a></div>
}
