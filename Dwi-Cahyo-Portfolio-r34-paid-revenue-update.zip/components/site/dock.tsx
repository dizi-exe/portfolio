'use client'
import { Headphones, Moon, Sun, Menu, X } from 'lucide-react'
import { useTheme } from 'next-themes'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
const items=[{id:'campaigns',label:'Work',href:'/#selected-work'},{id:'about',label:'About',href:'/#about'},{id:'contact',label:'Contact',href:'/#contact'},{id:'music',label:'Music',href:'/music'}]
export function Dock(){
 const[active,setActive]=useState('');const[open,setOpen]=useState(false);const pathname=usePathname();const{resolvedTheme,setTheme}=useTheme()
 useEffect(()=>{const sync=()=>{setActive(location.hash.slice(1));setOpen(false)};sync();window.addEventListener('hashchange',sync);return()=>window.removeEventListener('hashchange',sync)},[pathname])
 useEffect(()=>{if(!open)return;const close=(event:KeyboardEvent)=>{if(event.key==='Escape')setOpen(false)};window.addEventListener('keydown',close);return()=>window.removeEventListener('keydown',close)},[open])
 const selected=pathname.startsWith('/work/')?'campaigns':pathname==='/music'?'music':active
 return <nav aria-label="Main navigation" className={`top-hud compact-hud ${open?'menu-open':''}`}><a className="hud-brand" href="/#home" aria-label="Dwi Cahyo — Home" onClick={()=>setOpen(false)}>Dwi Cahyo<span>.</span></a><div id="portfolio-menu" className="hud-links">{items.map(i=><a key={i.id} href={i.href} aria-current={selected===i.id?(pathname.startsWith('/work/')?'true':'location'):undefined} onClick={()=>{setActive(i.id);setOpen(false)}}>{i.id==='music'&&<Headphones size={14}/>} {i.label}</a>)}</div><button type="button" className="hud-theme" aria-label="Toggle light and dark theme" onClick={()=>setTheme(resolvedTheme==='dark'?'light':'dark')}><Sun className="hidden dark:block" size={16}/><Moon className="dark:hidden" size={16}/></button><button type="button" className="hud-menu-toggle" aria-expanded={open} aria-controls="portfolio-menu" aria-label={open?'Close navigation':'Open navigation'} onClick={()=>setOpen(!open)}>{open?<X size={20}/>:<Menu size={20}/>}</button></nav>
}
