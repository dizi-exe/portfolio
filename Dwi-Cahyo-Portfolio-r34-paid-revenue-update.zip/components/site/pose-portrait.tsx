'use client'
import { useEffect, useState } from 'react'
import { ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react'
import { useReducedMotion } from '@/components/motion/use-reduced-motion'
const poses = ['ALE02682', 'ALE02687', 'ALE02670', 'ALE02679', 'ALE02678', 'ALE02688', 'ALE02689', 'ALE02690', 'ALE02691', 'ALE02692', 'ALE02693', 'ALE02694', 'ALE02695']
export function PosePortrait() {
  const [active, setActive] = useState(0)
  const [paused, setPaused] = useState(false)
  const reduced = useReducedMotion()
  useEffect(() => {
    if (paused || reduced) return
    const timer = setInterval(() => setActive(i => (i + 1) % poses.length), 2600)
    return () => clearInterval(timer)
  }, [paused, reduced])
  function move(direction: number) { setPaused(true); setActive(i => (i + direction + poses.length) % poses.length) }
  return <div className={`pose-player ${paused || reduced ? 'is-paused' : ''}`}>
    <div className="pose-frames" aria-label="Animated portraits of Dwi Cahyo">{poses.map((pose, i) => <img key={pose} src={`/portraits/${pose}.webp`} alt={i === active ? 'Dwi Cahyo, photographed in a casual or graduation pose' : ''} aria-hidden={i !== active} className={i === active ? 'active' : ''} loading={i === 0 ? 'eager' : 'lazy'} fetchPriority={i === 0 ? 'high' : 'auto'} />)}</div>
    <div className="pose-controls glass"><button type="button" aria-label="Previous portrait" onClick={() => move(-1)}><ChevronLeft size={13} /></button><button type="button" aria-label={paused ? 'Play portrait motion' : 'Pause portrait motion'} onClick={() => setPaused(!paused)} aria-pressed={paused} disabled={reduced}>{paused || reduced ? <Play size={12} /> : <Pause size={12} />}</button><button type="button" aria-label="Next portrait" onClick={() => move(1)}><ChevronRight size={13} /></button><span>{String(active + 1).padStart(2, '0')} / {poses.length}</span></div>
  </div>
}
