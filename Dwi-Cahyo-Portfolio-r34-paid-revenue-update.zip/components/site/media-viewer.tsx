"use client"
import { useRef } from 'react'
import { X, Maximize2 } from 'lucide-react'
export function MediaViewer({src,alt,label}: {src:string;alt:string;label?:string}) {
 const dialog=useRef<HTMLDialogElement>(null)
 return <><button className="media-trigger" aria-label={`Open ${alt}`} onClick={()=>dialog.current?.showModal()}><img src={src} alt={alt} loading="lazy"/><span><Maximize2 size={14}/>{label || 'View detail'}</span></button><dialog ref={dialog} className="media-dialog" onClick={e=>{if(e.target===e.currentTarget)dialog.current?.close()}}><button autoFocus className="dialog-close" aria-label="Close image" onClick={()=>dialog.current?.close()}><X/></button><img src={src} alt={alt}/><p>{alt}</p></dialog></>
}