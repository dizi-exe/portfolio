'use client'

import { useEffect, useRef, type CSSProperties } from 'react'
import { cn } from '@/lib/utils'

type ScrollRevealTextProps = {
  text: string
  highlight?: string[]
  className?: string
}

export function ScrollRevealText({ text, highlight = [], className }: ScrollRevealTextProps) {
  const ref = useRef<HTMLParagraphElement>(null)
  const words = text.split(' ')

  useEffect(() => {
    const el = ref.current
    if (!el) return

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      el.style.setProperty('--p', '1')
      return
    }

    let frame = 0
    const update = () => {
      frame = 0
      const rect = el.getBoundingClientRect()
      const vh = window.innerHeight
      const start = vh * 0.85
      const end = vh * 0.3
      const progress = (start - rect.top) / (start - end + rect.height * 0.6)
      el.style.setProperty('--p', String(Math.min(1, Math.max(0, progress))))
    }
    const schedule = () => {
      if (!frame) frame = requestAnimationFrame(update)
    }

    update()
    window.addEventListener('scroll', schedule, { passive: true })
    window.addEventListener('resize', schedule)
    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener('scroll', schedule)
      window.removeEventListener('resize', schedule)
    }
  }, [])

  return (
    <p ref={ref} className={className} style={{ '--n': words.length + 3 } as CSSProperties}>
      <span className="sr-only">{text}</span>
      <span aria-hidden="true">
        {words.map((word, i) => (
          <span
            key={`${word}-${i}`}
            className={cn('reveal-word', highlight.includes(word.replace(/[.,]/g, '')) && 'text-primary')}
            style={{ '--i': i } as CSSProperties}
          >
            {word}{' '}
          </span>
        ))}
      </span>
    </p>
  )
}
