'use client'
import { EditorialGallery } from './editorial-gallery'
const designs=[
{name:"Christmas Dinner",image:"christmas-0",detail:"Christmas Village \u00b7 Story design",url:"https://drive.google.com/file/d/1sCcWj2MHM5814BkQMrDdJODPhIcGp5z_/view"},{name:"The Art of Festive Gifting",image:"christmas-1",detail:"Christmas hampers \u00b7 Collection flyer",url:"https://drive.google.com/file/d/1aZux3CJuy96VZNQ8SVcbuBUBnyLUwiJ7/view"},{name:"Christmas Village Road",image:"christmas-2",detail:"Christmas hampers \u00b7 Product design",url:"https://drive.google.com/file/d/1CaQktN1UTcpZVaEH_PVruHvHqhXJxqM0/view"},{name:"Christmas Cookie Lane",image:"christmas-3",detail:"Christmas hampers \u00b7 Product design",url:"https://drive.google.com/file/d/1XVGoERAGQm-2OnTB0txQhRunZDOsQa6e/view"},{name:"The Christmas House",image:"christmas-4",detail:"Christmas hampers \u00b7 Product design",url:"https://drive.google.com/file/d/1DEh8TMXpvHCQNhfldsebEg8pCTi0FunO/view"},

 {name:'Wedding Showcase',image:'wedding-showcase-igs',detail:'Wedding event · Story design',url:'https://drive.google.com/file/d/1sFG2lZT5VhmVtcBg-5GU7XYD7VwYM9yh/view'},
 {name:'Artha Spa',image:'artha-spa',detail:'Spa packages · Story design',url:'https://drive.google.com/file/d/10PZWKnaazM47CHLQecQItrKQ9CP3a7QT/view'},
 {name:'A Taste of Forever',image:'a-taste-of-forever',detail:'Wedding dining · Promotional design'},
 {name:'The Grove Journey',image:'grove-journey-design',detail:'Staycation experience · Promotional design'},
 {name:'Meetings at GRANDASTON',image:'meetings-grandaston',detail:'Meeting packages · Promotional design'},
]
export function DesignGallery(){return <section className="design-gallery" aria-label="Selected graphic design"><div className="case-heading"><div><p className="eyebrow">THE GROVE SUITES BY GRAND ASTON · GRAPHIC DESIGN</p><h3 className="work-title">Campaigns, composed for the feed.</h3><p className="preview-description">Campaign artwork, dining experiences and festive gifting. Open any design to see the complete artwork.</p></div></div><EditorialGallery label="Graphic design" items={designs.map(item=>({title:item.name,src:`/work/${item.image}.webp`,detail:item.detail}))}/></section>}
