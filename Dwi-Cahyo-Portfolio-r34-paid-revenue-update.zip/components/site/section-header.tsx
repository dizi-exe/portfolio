import { RevealCopy } from '@/components/motion/reveal-copy'
type SectionHeaderProps = {
  id: string
  index: string
  label: string
  title: string
  kicker?: string
}

export function SectionHeader({ id, index, label, title, kicker }: SectionHeaderProps) {
  return (
    <div className="flex flex-col gap-5 pt-6 md:flex-row md:items-end md:justify-between">
      <div>
        <p className="font-mono text-xs text-primary">
          {index} <span className="text-muted-foreground">/ {label}</span>
        </p>
        <h2 id={id} className="mt-4 text-4xl font-bold tracking-tighter text-balance md:text-7xl">
          <RevealCopy text={title}/>
        </h2>
      </div>
      {kicker ? <p className="max-w-xs text-sm text-muted-foreground md:text-right">{kicker}</p> : null}
    </div>
  )
}
