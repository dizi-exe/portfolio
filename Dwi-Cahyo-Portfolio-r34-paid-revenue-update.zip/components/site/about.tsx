import { about, credentials, education, experience, tools } from '@/lib/content'
import { ScrollRevealText } from './scroll-reveal-text'
import { SectionHeader } from './section-header'

export function About() {
  return (
    <section aria-labelledby="about-title" id="about" className="px-5 py-20 md:px-10 md:py-32">
      <div className="mx-auto max-w-6xl">
        <SectionHeader id="about-title" index="04" label="Background" title="About" /><div className="profile-actions"><a href="https://drive.google.com/file/d/1TN1YBlZdKAgbTl3HWW2t4onjd-mKvNkr/view?usp=drivesdk" target="_blank" rel="noopener noreferrer" className="sweep-button">Download CV ↓</a><a href="#home" className="sweep-button subtle">Back to Home ↑</a></div>

        <ScrollRevealText
          text={about}
          className="mt-14 max-w-4xl text-2xl leading-snug font-medium tracking-tight text-pretty md:mt-20 md:text-4xl"
        />

        <div className="mt-20">
          <h3 className="font-mono text-[11px] tracking-[0.25em] text-muted-foreground uppercase">Experience</h3>
          <ol className="mt-4 border-t border-border">
            {experience.map((job) => (
              <li
                key={`${job.role}-${job.period}`}
                className="experience-row group"
              >
                <div>
                  <p className="text-xl font-semibold tracking-tight transition-colors group-hover:text-primary md:text-3xl">
                    {job.role}
                  </p>
                  <div className="employer-line"><span>{job.company}</span><small>{job.business}</small></div><p className="job-location">{job.location}</p><p className="job-description">{job.description}</p>
                </div>
                <p className="experience-period">
                  {job.period}
                </p>
              </li>
            ))}
          </ol>
        </div>

        <div className="education-block"><h3 className="eyebrow">ACADEMIC BACKGROUND</h3><div className="education-content"><div><p className="eyebrow">{education.period} · GPA {education.gpa}</p><h4>{education.degree}</h4><p>{education.university}</p><small>{education.faculty} · Jakarta, Indonesia.</small></div><div><p className="eyebrow">UNDERGRADUATE RESEARCH</p><h5>{education.research}</h5><p className="preview-description">{education.detail}</p></div></div></div>

        <div className="mt-20 grid gap-12 md:grid-cols-2">
          <div>
            <h3 className="font-mono text-[11px] tracking-[0.25em] text-muted-foreground uppercase">Tools</h3>
            <dl className="mt-6 flex flex-col gap-6">
              {tools.map((group) => (
                <div key={group.group}>
                  <dt className="text-sm font-semibold">{group.group}</dt>
                  <dd className="mt-3">
                    <ul className="flex flex-wrap gap-2">
                      {group.items.map((tool) => (
                        <li key={tool} className="rounded-full border border-border px-3 py-1.5 text-sm">
                          {tool}
                        </li>
                      ))}
                    </ul>
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          <div>
            <h3 className="font-mono text-[11px] tracking-[0.25em] text-muted-foreground uppercase">Credentials</h3>
            <ul className="mt-6 border-t border-border">
              {credentials.map((credential, i) => (
                <li key={credential.name} className="credential-row">
                  <span className="font-mono text-xs text-primary">{String(i + 1).padStart(2, '0')}</span>
                  <div><p className="credential-issuer">{credential.issuer}<span>{credential.kind}</span></p><h4>{credential.name}</h4><p className="credential-date">{credential.date}</p><p className="credential-scope">{credential.scope}</p><a className="embed-original" href="https://www.canva.com/design/DAHWgEtmEYg/view?page=26" target="_blank" rel="noreferrer">View credential evidence <span aria-hidden="true">↗</span></a></div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
