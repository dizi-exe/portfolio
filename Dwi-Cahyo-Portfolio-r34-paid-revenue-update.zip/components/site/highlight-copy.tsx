import { Fragment } from 'react'

const phrases = ['331.6K views', '18.3K interactions', '1.9K shares', '598 messaging conversations', '242 messaging conversations', '16.4K views', '99 follows', 'video concept and production', 'concept and storyboard', 'strategy, graphic design, video production, copywriting and Meta Ads', 'natural sound and deliberate pacing', 'WhatsApp', 'Kuningan', 'Veranda Restaurant', 'Rasuna Epicentrum', '25%', '14:00–15:00', 'Minang dishes', 'pool and gym access', 'pineapple, lychee and coconut', 'business or leisure stays', 'full hotel name', 'reservation action']
const pattern = new RegExp(`(${phrases.map(p=>p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')})`, 'gi')
export function HighlightCopy({text}:{text:string}) { return <>{text.split(pattern).map((part,i)=>i%2 ? <strong className="copy-emphasis" key={i}>{part}</strong> : <Fragment key={i}>{part}</Fragment>)}</> }
