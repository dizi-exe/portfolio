'use client'
import { useState } from 'react'
import { ArrowUpRight, Play, X } from 'lucide-react'
export function InstagramEmbed({ url, title, poster, slide, compact = false, initialOpen = false }: { url: string; title: string; poster?: string; slide?: number; compact?: boolean; initialOpen?: boolean }) {
  const [open, setOpen] = useState(initialOpen)
  const source = `${url.replace(/\?.*$/, '').replace(/\/$/, '')}/`
  const original = slide ? `${source}?img_index=${slide}` : source
  return <div className={`instagram-media ${source.includes('/reel/') || source.includes('/reels/') ? 'reel-media' : ''} ${compact ? 'compact' : ''} ${open ? 'is-open' : ''}`}>
    <div className="instagram-stage">{open ? <><iframe src={`${source}embed/`} title={`Instagram: ${title}`} loading="lazy" allow="encrypted-media; clipboard-write; fullscreen" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" /><button className="embed-close" type="button" aria-label={`Close ${title} embed`} onClick={() => setOpen(false)}><X size={16} /></button></> : <button className="embed-poster" type="button" onClick={() => setOpen(true)} aria-label={`Play Instagram ${title}`}>
      {poster ? <img src={poster} alt={`${title} original creative`} loading="lazy" /> : <span className="embed-title">{title}</span>}<span className="embed-play"><Play size={18} fill="currentColor" /><span>{source.includes('/reel/') ? 'Play Reel' : 'Explore post'}</span></span>
    </button>}</div>
    <a href={original} target="_blank" rel="noreferrer" className="embed-original">{slide ? `Open original · slide ${slide}` : 'Open original on Instagram'}<ArrowUpRight size={13} /></a>
  </div>
}
