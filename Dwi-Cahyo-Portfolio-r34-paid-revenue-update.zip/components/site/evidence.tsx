'use client'
import { KouventaPreview } from './kouventa-preview'
import { ArrowRight, ArrowUpRight } from 'lucide-react'
import { TiltCard } from '@/components/motion/tilt-card'
import { ReportingPreview } from './reporting-preview'
export function Evidence() {
 return <section className="px-5 py-20 md:px-10"><div className="mx-auto max-w-6xl"><p className="eyebrow">A CLOSER LOOK</p><h2 className="mt-4 text-4xl font-bold tracking-tight">The thinking behind the output.</h2><p className="mt-5 max-w-xl text-muted-foreground">Explore the guest communication and reporting systems behind the campaigns.</p><div className="evidence-grid mt-10"><KouventaPreview /><TiltCard className="report-preview"><p className="eyebrow">MARKETING REPORTING</p><h3>From connected data to a reviewed update.</h3><p className="preview-description">Ad results arrive in one sheet. I turn them into a short update: <strong>what we spent, how many inquiries came in, and what to check next.</strong></p><ReportingPreview /><div className="report-route"><span>Source data</span><ArrowRight size={14} /><span>Dashboard</span><ArrowRight size={14} /><span>Review</span></div><a href="#automation" className="embed-original">Explore the workflow <ArrowUpRight size={14} /></a></TiltCard></div></div></section>
}
