'use client'
import { useEffect, useRef, useState } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { useReducedMotion } from '@/components/motion/use-reduced-motion'
const results = [
  { value: 331575, display: '331.6K', label: 'Views on one ASMR Reel', kind: 'Organic content', detail: 'A room reset filmed as an ASMR story. 18.3K interactions, 1.9K shares and approximately 1.1K follows, as reported in October 2026.', note: 'One organic Reel; not the sum of multiple campaigns.', href: '#campaigns' },
  { value: 598, display: '598', label: 'Messaging conversations', kind: 'Sip Society · Meta Ads', detail: 'IDR 1,583,785 in ad spend at IDR 2,648 per messaging conversation. My scope covered strategy, creative production, copy, targeting and optimisation.', note: 'Platform-reported conversations may include repeat contacts. Bookings are tracked separately.', href: '#campaigns' },
  { value: 30, display: '20–30', label: 'Client accounts managed', kind: 'Agency project delivery', detail: 'At GetFound, now GTMLab, I coordinated client communication, SEO delivery, performance reviews and strategy adjustments across a portfolio of client accounts.', note: 'Account portfolio, July–October 2024.', href: '#seo' },
]
function Counter({ value, display }: { value: number; display: string }) {
  const node = useRef<HTMLSpanElement>(null)
  const reduced = useReducedMotion()
  useEffect(() => {
    const element = node.current
    if (!element || reduced || display.includes('–')) return
    let frame = 0
    let played = false
    const observer = new IntersectionObserver(entries => {
      if (!entries.some(entry => entry.isIntersecting) || played) return
      played = true
      const start = performance.now()
      function tick(now: number) {
        const progress = Math.min((now - start) / 1100, 1)
        const number = value * (1 - Math.pow(1 - progress, 3))
        element!.textContent = progress === 1 ? display : value > 10000 ? `${(number / 1000).toFixed(1)}K` : Math.round(number).toLocaleString('en-US')
        if (progress < 1) frame = requestAnimationFrame(tick)
      }
      frame = requestAnimationFrame(tick)
    }, { threshold: 0.5 })
    observer.observe(element)
    return () => { observer.disconnect(); cancelAnimationFrame(frame); element.textContent = display }
  }, [value, display, reduced])
  return <span ref={node} aria-hidden="true">{display}</span>
}
export function AnimatedResults() {
  const [active, setActive] = useState(0)
  const current = results[active]
  return <div className="results-explorer">
    <p className="eyebrow">Selected results · different projects & periods</p>
    <div className="result-grid">{results.map((result, index) => <button type="button" key={result.label} className={`result-card ${index === active ? 'is-selected' : ''}`} aria-pressed={index === active} aria-controls="result-context" onClick={() => setActive(index)}>
      <span className="result-kind">{result.kind}</span><strong aria-label={result.display}><Counter value={result.value} display={result.display} /></strong><span>{result.label}</span><span className="result-cta">Explore the result <ArrowUpRight size={14} /></span>
    </button>)}</div>
    <div id="result-context" className="result-context" aria-live="polite"><div><h3>{current.kind}</h3><p>{current.detail}</p><small>{current.note}</small></div><a href={current.href} className="sweep-button"><span>See the work</span><ArrowUpRight size={16} /></a></div>
  </div>
}
