import Link from 'next/link'
import { PosePortrait } from './pose-portrait'
import { AnimatedLink } from '@/components/motion/animated-link'
import { ArrowDown, ArrowUpRight, Headphones } from 'lucide-react'
import { profile } from '@/lib/content'
export function Hero() {
 return <section id="home" aria-labelledby="hero-title" className="hero px-5 md:px-10">
  <header className="mx-auto flex max-w-6xl items-center justify-between py-7"><a href="#home" className="text-lg font-bold">Dwi Cahyo<span className="text-primary">.</span></a><Link href="/music" className="glass-pill"><Headphones size={16}/> Off the clock <ArrowUpRight size={14}/></Link></header>
  <div className="hero-grid mx-auto max-w-6xl">
   <div><p className="eyebrow">JAKARTA · DIGITAL MARKETING & CREATIVE PRODUCTION</p><h1 id="hero-title" className="hero-title">Good strategy.<br/>A little <span>curiosity.</span><br/>Work that moves.</h1><p className="mt-7 max-w-xl text-lg leading-relaxed text-muted-foreground">I’m Dwi. I build campaigns, make videos, and connect the systems behind them. Currently at The Grove Suites by Grand Aston.</p><div className="mt-9 flex flex-wrap gap-3"><AnimatedLink href="#campaigns">Explore my work</AnimatedLink><AnimatedLink href="#contact" className="subtle">Let’s talk</AnimatedLink></div><p className="mt-8 text-xs text-muted-foreground">Strategy · Design · Video · Paid media · SEO · Automation</p></div>
   <div className="portrait-stage"><div className="portrait-orb"/><div className="portrait-orbit" aria-hidden="true"/><PosePortrait /><div className="portrait-note glass"><span className="status-dot"/> Open to creative conversations</div><Link href="/music" className="music-note glass"><Headphones size={22}/><div><p className="text-xs text-muted-foreground">ALSO IN THE MIX</p><p className="font-semibold">Music, words & late-night ideas</p></div><ArrowUpRight size={18}/></Link></div>
  </div><a href="#intro" className="mx-auto mb-8 flex w-fit items-center gap-2 text-xs text-muted-foreground">Keep exploring <ArrowDown size={14}/></a>
 </section>
}