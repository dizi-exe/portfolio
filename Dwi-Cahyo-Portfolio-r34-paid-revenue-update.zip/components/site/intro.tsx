import { AnimatedResults } from './animated-results'
import { profile } from '@/lib/content'
import { ScrollRevealText } from './scroll-reveal-text'

export function Intro() {
  return (
    <section id="intro" aria-label="Introduction" className="px-5 py-24 md:px-10 md:py-40">
      <div className="mx-auto max-w-5xl">
        <ScrollRevealText
          text={profile.intro}
          highlight={['campaigns', 'content', 'systems']}
          className="text-3xl leading-[1.15] font-medium tracking-tight text-pretty md:text-6xl"
        />

        <AnimatedResults />

      </div>
    </section>
  )
}
