'use client'
import { useEffect, useRef, useState, type KeyboardEvent } from 'react'
import { ArrowRight, Check, Pause, Play, RotateCcw } from 'lucide-react'
import { useReducedMotion } from '@/components/motion/use-reduced-motion'
import { MakeBlueprint } from './make-blueprint'
import { SectionHeader } from './section-header'
const flows = [
  { title: 'Lead tracking & auto replies', status: 'Designed & tested', description: 'From an unstructured DM to a clear reply and a trackable inquiry.', tools: 'Make · OpenAI · Meta · Google Sheets', contribution: 'Workflow design, classification and reply logic, field mapping, validation, duplicate checks and testing.', steps: [
    { title: 'DM capture', input: '“We’re planning a company meeting for 80 people.”', output: 'Raw message logged', detail: 'Keep the original inquiry in a raw log before processing it. The incoming webhook remains the capture point.' },
    { title: 'Intent classification', input: 'Raw Instagram inquiry', output: 'Meeting & corporate event', detail: 'Identify the service, sales intent and available event details. Missing information remains visible for follow-up.' },
    { title: 'Reply & qualification', input: 'A meeting inquiry with missing event details', output: 'Relevant reply + inquiry form', detail: 'Use the configured reply logic, clean extracted fields, check duplicates and validate the record before routing it.' },
    { title: 'Google Sheets', input: 'Validated inquiry', output: 'Qualified record + team follow-up', detail: 'Map the inquiry into the structured database so the relevant team can follow up and track outcomes.' },
  ] },
  { title: 'A daily report, without copying every number', status: 'Daily review', description: 'Collect ad results automatically, organise them in one sheet, then explain what happened and what needs attention.', tools: 'Windsor.ai · Google Sheets · ChatGPT', contribution: 'Data-source configuration, metric mapping, dashboard structure, review instructions and reporting rules.', steps: [
    { title: 'Collect ad results', input: 'Meta Ads account', output: 'Spend, clicks and messaging conversations', detail: 'Windsor.ai brings the selected ad account’s results into the reporting process. Set the date range so the report answers a specific question.' },
    { title: 'Organise the numbers', input: 'Platform fields and campaign data', output: 'Aligned metrics & definitions', detail: 'Put spend, campaign names and inquiries into clearly labelled columns. Divide spend by inquiries to see how much each conversation costs.' },
    { title: 'See the results', input: 'Mapped marketing metrics', output: 'A readable performance view', detail: 'The sheet shows what was spent and what came back. For example, Sip Society spent Rp1,583,785 and generated 598 conversations, about Rp2,648 each.' },
    { title: 'Explain & check', input: 'Dashboard data', output: 'Draft report + human checks', detail: 'ChatGPT drafts a readable update from the sheet. I check the numbers and booking records, then decide what deserves attention or a new test.' },
  ] },
]
function Workflow({ flow, index }: { flow: typeof flows[number]; index: number }) {
  const [active, setActive] = useState(0)
  const [playing, setPlaying] = useState(false)
  const buttons = useRef<(HTMLButtonElement | null)[]>([])
  const reduced = useReducedMotion()
  useEffect(() => {
    if (!playing) return
    if (reduced) { setActive(flow.steps.length - 1); setPlaying(false); return }
    let step = 0
    const interval = setInterval(() => {
      step += 1
      setActive(Math.min(step, flow.steps.length - 1))
      if (step >= flow.steps.length - 1) { clearInterval(interval); setPlaying(false) }
    }, 1000)
    return () => clearInterval(interval)
  }, [playing, reduced, flow.steps.length])
  function choose(i: number) { setPlaying(false); setActive(i) }
  function keyboard(event: KeyboardEvent<HTMLButtonElement>, i: number) {
    const next = event.key === 'ArrowDown' || event.key === 'ArrowRight' ? (i + 1) % 4 : event.key === 'ArrowUp' || event.key === 'ArrowLeft' ? (i + 3) % 4 : event.key === 'Home' ? 0 : event.key === 'End' ? 3 : null
    if (next === null) return
    event.preventDefault(); choose(next); buttons.current[next]?.focus()
  }
  const step = flow.steps[active]
  return <article className="workflow-card"><div className="workflow-heading"><div><span className="eyebrow">{String(index + 1).padStart(2, '0')} / SYSTEM</span><h3>{flow.title}</h3></div><span className="workflow-status">{flow.status}</span></div><p className="workflow-intro">{flow.description}</p>
    <div className="workflow-interactive"><div className="workflow-steps" role="tablist" aria-label={`${flow.title} steps`} aria-orientation="horizontal">{flow.steps.map((s, i) => <button key={s.title} ref={el => { buttons.current[i] = el }} type="button" role="tab" aria-selected={active === i} aria-controls={`workflow-panel-${index}`} id={`workflow-tab-${index}-${i}`} tabIndex={active === i ? 0 : -1} onKeyDown={e => keyboard(e, i)} onClick={() => choose(i)} className={active === i ? 'active' : ''}><span>{playing && i < active ? <Check size={13} /> : String(i + 1).padStart(2, '0')}</span>{s.title}</button>)}</div>
      <div className="workflow-detail" id={`workflow-panel-${index}`} role="tabpanel" aria-labelledby={`workflow-tab-${index}-${active}`} tabIndex={0}><span className="eyebrow">Step {active + 1} of 4</span><h4>{step.title}</h4><p>{step.detail}</p><div className="workflow-data"><small>INPUT</small><span>{step.input}</span><ArrowRight size={15} aria-hidden="true" /><small>OUTPUT</small><strong>{step.output}</strong></div></div></div>
    <div className="workflow-play"><button type="button" className="sweep-button" aria-pressed={playing} onClick={() => { if (playing) setPlaying(false); else { setActive(0); setPlaying(true) } }}><span>{playing ? 'Pause walkthrough' : 'Play walkthrough'}</span>{playing ? <Pause size={13} /> : <Play size={13} />}</button><button type="button" className="icon-action" aria-label={`Reset ${flow.title}`} onClick={() => choose(0)}><RotateCcw size={15} /></button><small>Illustrative walkthrough</small></div>
    <div className="workflow-notes"><p><strong>Tools</strong>{flow.tools}</p><p><strong>My contribution</strong>{flow.contribution}</p></div>
  </article>
}
export function Automation() {
  const [system, setSystem] = useState(0)
  return <section aria-labelledby="automation-title" id="make-workflows" className="automation-studio"><div className="mx-auto max-w-6xl"><SectionHeader id="automation-title" index="02" label="Systems" title="Less repetition. More room to think." kicker="Follow the logic. Explore a step, or play the walkthrough." /><div className="system-switch" role="group" aria-label="Choose automation system">{flows.map((flow,i)=><button key={flow.title} aria-pressed={system===i} onClick={()=>setSystem(i)}><span>0{i+1}</span>{i===0?'Lead capture & follow-up':'Daily performance reporting'}<ArrowRight size={16}/></button>)}</div>{system===0&&<MakeBlueprint/>}<div className="workflows-grid"><Workflow key={system} flow={flows[system]} index={system}/></div></div></section>
}
