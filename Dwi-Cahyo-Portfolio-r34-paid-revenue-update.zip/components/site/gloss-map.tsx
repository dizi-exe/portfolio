'use client'
import { useEffect, useRef, useState } from 'react'
import type * as Leaflet from 'leaflet'
import { ArrowUpRight, LocateFixed } from 'lucide-react'
import { glossBusiness as business, glossKeywords } from '@/lib/gloss-data'

type MapState = {map:Leaflet.Map;layer:Leaflet.LayerGroup;L:typeof Leaflet}
const coordinates = (x:number,y:number): [number,number] => [business.lat+(2-y)*.5/110.574,business.lng+(x-2)*.5/(111.32*Math.cos(business.lat*Math.PI/180))]
const bounds = [coordinates(0,0),coordinates(4,4)]
export function GlossMap() {
  const [active,setActive]=useState(0)
  const [view,setView]=useState<'before'|'after'>('after')
  const [ready,setReady]=useState(false)
  const [error,setError]=useState(false)
  const host=useRef<HTMLDivElement>(null)
  const mapState=useRef<MapState|null>(null)
  const current=glossKeywords[active]
  const snapshot=current[view]
  const cells=snapshot.grid.flat()
  const average=cells.reduce((sum,rank)=>sum+rank,0)/cells.length
  const share=Math.round(cells.filter(rank=>rank<=3).length/cells.length*100)
  useEffect(()=>{
    let cancelled=false
    let observer:ResizeObserver|undefined
    async function setup(){
      try {
        const L=await import('leaflet')
        if(cancelled||!host.current)return
        const map=L.map(host.current,{scrollWheelZoom:false,dragging:!L.Browser.mobile,zoomSnap:.25,zoomAnimation:!window.matchMedia('(prefers-reduced-motion: reduce)').matches})
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'}).on('tileerror',()=>{if(!cancelled)setError(true)}).addTo(map)
        map.fitBounds(L.latLngBounds(bounds),{padding:[35,35]})
        mapState.current={map,L,layer:L.layerGroup().addTo(map)}
        observer=new ResizeObserver(()=>map.invalidateSize({pan:false}))
        observer.observe(host.current)
        setReady(true)
      } catch { if(!cancelled)setError(true) }
    }
    const intersection=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting)){intersection.disconnect();void setup()}},{rootMargin:'300px'})
    if(host.current)intersection.observe(host.current)
    return ()=>{cancelled=true;intersection.disconnect();observer?.disconnect();mapState.current?.map.remove();mapState.current=null}
  },[])
  useEffect(()=>{
    const state=mapState.current
    if(!ready||!state)return
    const {L,layer}=state
    layer.clearLayers()
    snapshot.grid.forEach((row,y)=>row.forEach((rank,x)=>{
      const tone=rank<=3?'rank-green':rank<=10?'rank-yellow':'rank-red'
      L.marker(coordinates(x,y),{icon:L.divIcon({className:'rank-marker',html:`<span class="${tone}">${rank}</span>`,iconSize:[26,26],iconAnchor:[13,13]}),title:`Row ${y+1}, column ${x+1}: rank ${rank}`,keyboard:true}).bindTooltip(`Rank ${rank} · ${snapshot.date}`).addTo(layer)
    }))
    L.circleMarker([business.lat,business.lng],{radius:23,color:'#67e8f9',weight:2,fill:false,interactive:false}).addTo(layer)
  },[ready,snapshot])
  return <section id="gloss-map" className="gloss-case" aria-labelledby="gloss-map-title">
    <div className="case-heading"><div><p className="eyebrow">GLOSS PATROL · LOCAL SEARCH</p><h3 id="gloss-map-title">Visibility, on the map.</h3><p className="preview-description">These are the <strong>two best-performing keywords we optimised</strong> for Gloss Patrol Serpong. Compare their before-and-after rankings across <strong>25 search locations</strong>.</p></div><span className="case-period">19 July – 8 August 2024</span></div>
    <div className="preview-switch" role="group" aria-label="Heatmap keyword">{glossKeywords.map((item,i)=><button type="button" key={item.keyword} aria-pressed={active===i} onClick={()=>setActive(i)}>{item.keyword}</button>)}</div>
    <div className="gloss-layout"><div><div className="rank-map-wrap"><div className="rank-map" ref={host} role="region" aria-label={`Interactive ranking map: ${current.keyword}, ${snapshot.date}`}/>{!ready&&<p className="map-loading">{error?'Map unavailable. Explore the ranking data below.':'Loading local search map…'}</p>}<button type="button" className="map-reset" onClick={()=>{const s=mapState.current;if(s)s.map.fitBounds(s.L.latLngBounds(bounds),{padding:[35,35]})}} aria-label="Reset map to scan area"><LocateFixed size={16}/>Reset view</button></div><p className="source-note">1 km scan radius · Cyan ring: business location. Point positions reconstructed around the supplied business coordinates; rankings transcribed from the original report.</p><a className="embed-original" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(business.name)}&query_place_id=${business.placeId}`}>Open business in Google Maps<ArrowUpRight size={13}/></a></div>
      <aside className="rank-summary"><div role="group" aria-label="Heatmap snapshot" className="snapshot-switch">{(['before','after'] as const).map(key=><button type="button" key={key} onClick={()=>setView(key)} aria-pressed={view===key}><span>{key==='before'?'Before':'After'}<small>{current[key].date}</small></span><strong>#{current[key].position}</strong></button>)}</div><div className="rank-statistics" aria-live="polite"><div><strong>{share}%</strong><span>of points in the top 3</span></div><div><strong>{average.toFixed(2)}</strong><span>average of displayed points</span></div></div><p className="source-note">The headline # position is the business’s position in the report’s comparison list. It is separate from the ranking at any individual grid point.</p><div className="rank-legend"><span><i className="rank-green"/>1–3</span><span><i className="rank-yellow"/>4–10</span><span><i className="rank-red"/>11–20</span></div></aside></div>
    {ready&&error?<p className="source-note" role="status">Some map tiles could not load. The ranking points and comparison data remain available.</p>:null}
    <div className="competitor-panel"><div><p className="eyebrow">THE COMPETITIVE CONTEXT</p><h4>Businesses in the same scan</h4><p className="source-note">Selected comparison rows from the {snapshot.date} report, for “{current.keyword}”. Comparison averages are reported values; grid statistics are calculated from the visible points.</p></div><div className="competitor-table"><table><thead><tr><th scope="col">Position</th><th scope="col">Business</th><th scope="col">Avg. rank</th></tr></thead><tbody>{[{name:business.name,position:snapshot.position,average:snapshot.comparisonAverage},...snapshot.competitors].sort((a,b)=>a.position-b.position).map(row=><tr key={row.name} className={row.name===business.name?'client-row':''}><td>#{row.position}</td><th scope="row">{row.name}</th><td>{row.average.toFixed(2)}</td></tr>)}</tbody></table></div></div>
    <details className="ranking-details"><summary>View all 25 ranking values</summary><div className="competitor-table"><table><caption>{current.keyword} · {snapshot.date} · north to south, west to east</caption><thead><tr><th scope="col">Row</th>{[1,2,3,4,5].map(i=><th key={i} scope="col">Column {i}</th>)}</tr></thead><tbody>{snapshot.grid.map((row,y)=><tr key={y}><th scope="row">{y+1}</th>{row.map((rank,x)=><td key={x}>{rank}</td>)}</tr>)}</tbody></table></div></details>
  </section>
}
