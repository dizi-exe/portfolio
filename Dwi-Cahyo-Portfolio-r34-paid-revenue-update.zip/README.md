# Dwi Cahyo portfolio

Next.js portfolio with Helvetica and Plus Jakarta Sans, a separate `/music` page and restrained glass styling.

Run `npm ci`, then `npm run dev`. Validate with `npm run build` and `npx tsc --noEmit`.

## October 14 content and evidence update

- Windsor.ai reporting is explained through Collect / Calculate / Explain, using the retrieved Sip Society results and a plain-language summary.
- Gloss Patrol uses Leaflet and public OpenStreetMap tiles, with keyword and snapshot controls, 25 real ranking values per snapshot, calculated top-three shares and the original report's competitor comparison rows.
- Ranking data was transcribed from the original GetFound Month 1 PDF, pages 6–7. The radius is 1 km. Geographic point positions are reconstructed around the supplied business coordinates; the original scan does not provide individual coordinates.
- The ppf mobil before-map values average 3.84, while the original comparison table reports 3.96. Both source representations are preserved separately; the grid is not changed to force agreement. The map's before top-three share is 52%.
- Three Meta Ads campaign rows were retrieved via Windsor.ai on 14 October 2026 for 1 August 2025–13 October 2026. The public JSON contains only the selected campaign figures. Cost per conversation is calculated; historical booking ROAS is labelled separately and was not returned by this query.
- Experience has full month/year ranges, employer descriptions, consistent location formatting, corrected HAI Online / Grid.ID and Ghazal’s names, and source-aligned Kakak Asuh and HAI dates.
- Education and undergraduate research have been added. Credentials distinguish courses, certification, bootcamp and event participation, with issuer, full title, date and scope.
- Zahara Dental Care and Jasmine Dental Clinic have original copywriting / graphic-design samples for WATI WhatsApp Business API broadcasts. Paradenta and drg. Sonia demonstrate local SEO writing, including the original Medium article link and backlink context.
- Bahana has eight supplied Instagram posts in a horizontally scrollable feed with original image covers and click-to-load embeds, with selected writing / talent slide links. The surrounding video card now fills its available width.
- The interactive coverflow gallery shows Wedding Showcase, Artha Spa, A Taste of Forever, The Grove Journey and Meetings at GRANDASTON. Christmas Dinner is deliberately excluded. Designs retain their full aspect ratio and open in a full-size viewer.
- GetFound and Bahana talent examples are on the main page. The explicit CART clip is on /music behind an explicit-language gate and is not loaded before it is opened.
- JetBrains Mono was removed. Main typefaces are Helvetica and Plus Jakarta Sans, with Arial as a device fallback when Helvetica is unavailable. Embedded third-party posts retain platform typography.

## Earlier motion revision

- Rotating stack of three original Sip Society photographs selected from the portfolio.
- Thirteen transparent portrait poses with crossfades, pause and navigation controls; moving abstract shapes behind the portrait.
- Animated button sweeps, continuous typography marquee and selective moving gradient borders.
- Interactive result cards, animated counters, step-by-step workflow walkthroughs and glass cards that tilt and zoom on hover.
- Six original hotel Instagram Reels, Bahana video and seven music artwork posts with click-to-load embeds and original-source links.
- Compact screenshot evidence with a full-size image viewer, readable supporting copy and a Kouventa WhatsApp Business API simulation imported from 111 supplied nodes and 110 connections.
- Original Sip Society article preview with the published image, title and a direct source link. The hotel website blocks cross-origin iframe embedding.
- Expanded experience and tools from the supplied screenshots.
- Original YouTube thumbnails and embeds for Flare and Pain.fm; Pain.fm recording and direction credits.
- Eleven song-specific links. Pain.fm uses Musixmatch; other songs use verified individual Shazam, Bandcamp, Amazon Music or Spotify pages. No rows link to the generic creator credits page.

## Remaining source constraints

The v0 references inform the animation direction; their source code was not available from the public template pages. These are native implementations rather than imported templates.

Instagram can restrict embedded playback. Every embed retains a direct original-source link. The article uses a published preview card because its server sends X-Frame-Options: SAMEORIGIN. Instagram carousel links identify the requested contribution slide; the embedded post itself may open on the first slide. TikTok and Instagram playback remains subject to platform availability.

Low-resolution screenshots are displayed compactly rather than artificially reconstructed. Credentials still link to the source portfolio evidence; individual certificate documents were not supplied.

## Validation

Production build and TypeScript checks pass. Current browser checks verified the native reporting stage switch, Meta Ads campaign switch, Bahana feed navigation, unclipped experience dates, original design assets, real map tiles and 25 ranking markers, keyword/snapshot switching and competitor rows. The music warning gate was checked before and after opening, then reset. No horizontal overflow or broken local images was found at the inspected desktop viewport.

All 100 transcribed point values were validated for shape, numeric range, grid means and top-three shares. The report comparison average remains a separate field where it differs from the image grid.

The earlier motion revision also passed local Chromium checks for portrait/photo controls, KPI selection, workflow keyboard controls, image dialogs, music search, reduced motion and layouts at 390, 768 and 1440 pixels. This content update received deployed desktop browser checks; those previous mobile checks were not repeated for every new section.

Embed creation, source URLs and loaded Instagram post previews were observed. Uninterrupted third-party playback was not verified.

## Published revision

Published and verified on 14 October 2026:

- Portfolio: https://dwicahyo.vercel.app/
- Music: https://dwicahyo.vercel.app/music
- Preview: https://dwicahyo-ooj1g1n5m-portfolio-72ff.vercel.app/
- Production deployment: `dpl_G7dowqbTexjh8DxpgAt8vHhM4nNn` (`READY`)

Vercel built the reviewed source for production and successfully assigned the main domain. Both the updated portfolio and /music were verified on the production domain.

The source was uploaded directly to the existing Vercel project. The original v0 editor has not been synchronized with this revision; publishing its older source can overwrite this deployment. Use this source archive for further changes.

## Latest revision

- Video thumbnails use 16:9 containers with uncropped artwork. Instagram chrome appears only after a visitor opens an embed.
- Talent and CART meme cards use original media covers and public likes/comments/shares checked on 14 October 2026. View counts were not available on the inspected detail pages. CART is credited for content ideation and on-camera talent.
- Hadiah Awal Tahun includes Main PIC / Project Manager credits and an interactive release-plan timeline. Bahana uses the supplied 2024 document as a format reference, without attributing its campaign content to the earlier internship.
- Reporting and Kouventa use explanatory interactive walkthroughs. Kouventa is a portfolio simulation and sends no messages. Original media filenames appear when the archived flow sends an attachment.
- Gloss Patrol before/after figures lead the layout beside a smaller real map.
- Contact includes Back to Home. Audio production, content publishing, project management and WhatsApp communications are separate tool groups.

## Experience chapters and expanded work

- Three employer selectors (The Grove, Bahana Sekuritas, GetFound), each with focused work categories. Only the selected collection is mounted. Music stays on its own page.
- Added all 25 supplied Reels with original Instagram cover assets, grouped into F&B transitions, campaign videos, room stories, daily content and Saham Sehat. Daily-content camera/talent credits follow the supplied annotations.
- Added 31 supplied GetFound client businesses/locations as a filterable text roster, without invented logos or direct-employment claims.
- Leads Dashboard snapshot read 15 October 2026 WIB: 1,176 captured, 1,157 greeted, 54 converted, 36 paid; recorded revenue Rp316,104,652 and revenue marked Paid Rp249,221,292. The period is 3 December 2025–14 October 2026. Paid total was checked against the tracker payment column. Aggregates only; no lead names, contact details or raw records are published.
- These are recorded tracker values across sources, not all hotel revenue or an ads-attribution claim.
- Gloss Patrol keywords are labelled as the two best-performing optimised keywords.
- Christmas Dinner remains excluded from both the gallery and deployment assets.


## Revision 4 deployment
Production deployment: dpl_9vRxarSDok3bQTxpuQaFYTc2SEzB.
Preview reviewed: dpl_9Uw3JSbgM5AyzE4vjqDvwvRtnm7j. Build passed. Browser checks covered experience/category switching, Bahana pagination, 25 map markers at 320px height, client filtering, Pesta Bola spend, lead workflow, and gallery navigation. No broken images or horizontal overflow in reviewed desktop gallery.


## Revision 5 — navigation, storytelling and interaction

Production deployment: dpl_2jYPK2rVCV3aamRUw5MQhYWyyvvj.

Top navigation with text labels; glass controls and creative hover treatments; copy reveals with reduced-motion support; four interactive campaign stories; mobile Bahana planning padding; contextual video and carousel titles; Selected results first; About/Home actions and locally hosted CV; tracked-revenue-only lead summary; Make walkthrough restored; interactive Kouventa nodes from supplied configuration.

Validation: Next.js production build and TypeScript passed. Browser checks at desktop and 375px content width verified planning interaction without horizontal page overflow, Home return, selected results order, story chapters and Kouventa branching. Historical performance figures remain saved snapshots.

## Revision 8 — 16 October 2026

- Preserved the established hero and introduction.
- Horizontal original-cover showcases for videos, graphic design and agency talent; click-to-open accessible details, manual navigation and reduced-motion support.
- Campaign Results is the first Grove tab. Campaign stories show the full narrative and distinguish OpenTopTour's tour-partner role and Archipelago's national 60 Seconds to Seoul campaign from Dwi's video contribution.
- Social-caption examples use verified 2026 posts with original covers. Unverified older examples and undated Search Console totals were removed.
- Expanded GetFound responsibilities, highlighted three client relationships, corrected Gloss Patrol marker alignment and restored section padding.
- Added five Christmas promotional designs from the supplied Drive folder. No new videos or photography were added from that folder.
- Updated compact footer and subtle moving background gradient. The existing photography remains pending separate approval for additions.
- Validation: Next production build and TypeScript passed; local image references checked. Browser interaction/visual QA was not available in this environment.

## Revision 9 — 16 October 2026

- Portrait-led grid showcase, captions beneath each asset, scroll entrance motion and hover feedback; reduced-motion support retained.
- Results followed by selected films on the initial Grove view for a longer reading flow.
- Single-column local SEO accordions prevent an unopened panel from stretching alongside its neighbour.
- Social SEO examples use spacious editorial rows; the measurement note is compact.
- Campaign story posters use portrait wrappers matching the Reel format.
- Wedding Showcase uses the supplied 9:16 story artwork. Press releases use verified original website thumbnails.
- Added only the three approved photographs: Emerald Boardroom, Grooviest cake detail and whole cake. Other photo candidates remain outside the site.
- GBP post titles/thumbnails remain pending: the supplied Google share links cannot currently be resolved (HTTP 429). Original links remain available in a compact list; no guessed title/image mapping was added.
- Validation: production build/TypeScript and referenced asset checks. Browser visual QA unavailable in this environment.

## Revision 10 — 15 October 2026
- Grove, GetFound, Bahana company order; restored separate Design and Photography accordions.
- Added approved Sate Maranggi and Orange Coffee photographs; removed the redundant Sip Society evening group photo from the gallery.
- Campaign Stories use expandable visual galleries and external original-video links. Existing covers are identified as covers; new photo candidates remain pending approval.
- Added July promotion revenue: 60 Seconds to Tokyo Rp8,644,562; Nobar Piala Dunia / Pesta Bola Rp16,249,017. Verified source cells: Promo & Activities Target!I42:I43, supplied 2026 workbook. Workbook contains private guest information and is excluded from this archive and deployment.
- Pesta Bola revenue / Meta ad spend = 47.43x (16,249,017 / 342,570). Mixed-source promotion revenue cannot establish ad-attributed ROAS. Removed historical unverified ROAS labels.
- Mapped all three GBP links to screenshot-confirmed titles and copy analysis. Illustrations are corresponding campaign artwork from Drive, labeled accordingly.
- Next.js production build and TypeScript passed. Browser visual QA unavailable in this environment.

## Revision 11 — 16 October 2026
- Dedicated /work/grove, /work/getfound and /work/bahana pages; homepage links to each company. Simplified category underline navigation.
- Bottom next/previous category navigation with focus and scroll management, followed by the next company and About.
- Local SEO scope visualisations, selective copy emphasis, readable credential evidence buttons.
- Off the Clock artwork now uses complete image thumbnails and accessible detail dialogs.
- Promotion results use named campaign panels and clear revenue/ad-spend labels. Full 60 Seconds to Tokyo name; Pesta Bola display subtitle removed.
- Interactive Make node explorer uses 5 capture modules and 23 qualifier modules extracted from supplied blueprints. Private configuration excluded; no claim of live execution.
- Campaign visual galleries moved below the narrative at full width, preserving image ratios. Sip Society uses the existing approved photographs. Other campaigns retain labeled artwork/covers pending approval of actual campaign photos.
- New photo shortlist remains pending approval; no extra photographs published.

## Revision 12 — 16 October 2026
- Fixed GBP emphasis rendering as separate blocks; inline highlights retain paragraph flow.
- Next/previous and category tabs focus the existing work-content target, then scroll instantly below the measured HUD.
- Reduced global navigation to Work, About, Contact and Music; brand returns home. Collapsible mobile navigation, stronger background and correct work-page context.
- Reworked company introductions, separated results from the video library, and added an inquiry-to-booking process visual with existing tracked-revenue context.
- Added numbered campaign narrative structure, client-story emphasis, reveal animations and planning-stage indicators with reduced-motion support.
- Browser interaction/visual QA unavailable in this environment. Build and TypeScript validation performed.
