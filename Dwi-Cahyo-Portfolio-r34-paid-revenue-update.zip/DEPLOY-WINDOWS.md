# Deploy from Windows

Revision 7 — 15 October 2026.

Includes capped video/On-camera previews, shared liquid-glass cards, shaded backgrounds, corrected Contact contrast, full hotel naming, interactive SEO/HTML analysis, the three selected press releases, original GBP and Instagram links, and redesigned Automation navigation.

The SEO section distinguishes observed Search Console clicks from editorial query-fit analysis. GBP short links and some external pages could not be read automatically; they are linked directly without invented captions. Instagram embeds and Google share links depend on the external platforms.

Build and TypeScript checks passed. Latest visual changes have not been browser-verified. This ZIP has not been deployed to production.

1. Install Node.js LTS from https://nodejs.org/.
2. Extract this ZIP into a new folder, then open the folder containing package.json. Do not merge it into an older extracted version.
3. Type cmd in File Explorer's address bar and press Enter.
4. Run these commands one at a time:

    npm install -g vercel
    vercel login
    vercel link

Sign in with dwiiicahyooo27@gmail.com. Select the existing account/team and link to existing project dwicahyo. Do not create a new project.

Confirm the target and create a preview:

    vercel project inspect
    vercel

Check desktop and mobile using the preview URL. To publish:

    vercel --prod

Production domain: https://dwicahyo.vercel.app/

Optional local checks:

    npm ci
    npm run build
    npm run start

External embeds require internet. Excludes dependencies, build output, authentication files and internal source HTML exports.
