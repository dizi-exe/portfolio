// Transcribed from GetFound's original Month 1 report, pp. 6–7.
// North to south; west to east. Reported positions are business-list positions,
// distinct from the individual point rankings and average grid rank.
export const glossKeywords = [
  { keyword: 'ppf mobil', before: { date: '19 July 2024', position: 3, comparisonAverage: 3.96, grid: [[2,6,2,3,3],[2,2,2,3,5],[4,2,4,5,7],[2,2,4,7,2],[2,4,6,8,7]], competitors: [{name:'SCUTO Gading Serpong',position:1,average:1},{name:'Automobo Coating Expert Serpong',position:2,average:3.2}] }, after: { date: '8 August 2024', position: 1, comparisonAverage: 1.04, grid: [[1,2,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]], competitors: [{name:'ONEPRO PPF · Tangerang Alam Sutera',position:2,average:2.44},{name:'Solar Gard Paint Protection Film · Gading Serpong',position:3,average:2.92}] } },
  { keyword: 'pasang ppf mobil', before: { date: '19 July 2024', position: 6, comparisonAverage: 6.4, grid: [[11,5,8,9,6],[5,4,5,8,9],[5,3,6,8,4],[5,4,6,3,9],[5,4,9,9,10]], competitors: [{name:'MARK Gading Serpong',position:4,average:4.44},{name:'HD Car Care Serpong BSD',position:5,average:5.56}] }, after: { date: '8 August 2024', position: 1, comparisonAverage: 1.88, grid: [[2,2,2,2,2],[2,1,2,2,2],[2,1,1,2,2],[2,2,2,2,2],[2,2,2,2,2]], competitors: [{name:'ONEPRO PPF · Tangerang Alam Sutera',position:2,average:1.2},{name:'SCUTO Gading Serpong',position:3,average:3.56}] } },
]
export const glossBusiness = {lat:-6.2657016,lng:106.6268955,name:'Gloss Patrol Serpong',placeId:'ChIJIWXkh2j9aS4RYaNWLuWd38g'}
