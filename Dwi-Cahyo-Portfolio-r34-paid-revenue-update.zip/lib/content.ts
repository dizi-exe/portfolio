export const profile = {
  name: 'Dwi Cahyo',
  role: 'Digital Marketing Executive',
  company: 'The Grove Suites by Grand Aston',
  location: 'Depok, West Java, Indonesia',
  email: 'dwiiicahyooo27@gmail.com',
  whatsappDisplay: '+62 851 8304 4827',
  whatsappHref: 'https://wa.me/6285183044827',
  intro:
    'Digital Marketing Executive at The Grove Suites by Grand Aston. I build campaigns, create content, and develop the systems behind delivery and reporting.',
}

export const results = [
  { value: '331.6K', label: 'views on one ASMR Reel' },
  { value: '598', label: 'messaging conversations from Sip Society' },
  { value: '20–30', label: 'client accounts managed at GetFound' },
]

export type Metric = { value: string; label: string }

export type Campaign = {
  title: string
  category: string
  client?: string
  image: string
  imageAlt: string
  description: { before: string; emphasis: string; after: string }
  roles?: string
  metrics?: Metric[]
  note?: string
}

export const campaigns: Campaign[] = [
  {
    title: 'ASMR Hotel Room Reset',
    category: 'Instagram Reel',
    client: 'The Grove Suites by Grand Aston',
    image: '/media/VAHXD89iQcw.jpg',
    imageAlt: 'Original frame from the ASMR Hotel Room Reset video.',
    description: {
      before: 'Turned a room reset into an ',
      emphasis: 'ASMR story',
      after: ' using close-ups, natural sound, and deliberate pacing.',
    },
    roles: 'Concept · Direction · Filming · Editing',
    metrics: [
      { value: '331.6K', label: 'total views' },
      { value: '18.3K', label: 'interactions' },
      { value: '1.9K', label: 'shares' },
    ],
    note: 'Reported October 2026',
  },
  {
    title: 'Sip Society',
    category: 'Dining campaign',
    client: 'The Grove Suites by Grand Aston',
    image: '/media/VAHXC4WysxY.jpg',
    imageAlt: 'Original Sip Society campaign video frame.',
    description: {
      before: '',
      emphasis: 'Owned strategy',
      after: ', graphic design, filming, editing, copywriting, and Meta Ads execution.',
    },
    metrics: [
      { value: '598', label: 'messaging conversations' },
      { value: 'IDR 2,648', label: 'cost per conversation' },
      { value: 'IDR 1.58M', label: 'ad spend' },
    ],
    note: 'Messaging conversations are platform-reported and may include repeat contacts.',
  },
  {
    title: 'Bahana Sekuritas',
    category: 'Social Content',
    image: '/canva-6-580x799.jpeg',
    imageAlt: 'Original Bahana Sekuritas Anak Saham creative.',
    description: {
      before: 'Created investment education content through ',
      emphasis: 'planning, copywriting, scriptwriting, directing, filming, and editing.',
      after: '',
    },
  },
]

export const automations = [
  {
    title: 'Instagram Inquiry Automation',
    status: 'Designed and tested',
    description: {
      before: 'A Make workflow that captures Instagram DMs, sends ',
      emphasis: 'automated replies',
      after: ', and records qualified inquiries in Google Sheets.',
    },
    flow: ['DM capture', 'Intent classification', 'Automated reply & lead processing', 'Google Sheets'],
    tools: 'Make · OpenAI · Meta · Google Sheets',
    contribution: {
      emphasis: 'Workflow design, AI instructions, reply logic',
      rest: ', field mapping, validation, testing, and troubleshooting.',
    },
  },
  {
    title: 'Marketing Reporting Automation',
    status: 'Daily reviews',
    description: {
      before: 'Configured Windsor.ai data integration, ',
      emphasis: 'Google Sheets dashboards',
      after: ', and scheduled ChatGPT tasks for daily marketing reviews.',
    },
    flow: ['Windsor.ai sync', 'Metric mapping', 'Sheets dashboard', 'Scheduled ChatGPT review'],
    tools: 'Windsor.ai · Google Sheets · ChatGPT',
    contribution: {
      emphasis: 'Data-source configuration, metric mapping',
      rest: ', dashboard structure, and scheduled-review instructions.',
    },
  },
]

export const seo = {
  company: 'GetFound (now GTMLab)',
  role: 'Digital Project Manager',
  period: 'July – October 2024',
  city: 'Jakarta',
  intro: {
    before: 'Managed a portfolio of ',
    accounts: '20–30 client accounts',
    middle: ', coordinating client communication, SEO delivery, performance reviews, and ',
    strategy: 'strategy adjustments',
    after: '.',
  },
  highlight: {
    title: 'Gloss Patrol Serpong',
    label: 'Google Business Profile · June – July 2024',
    metrics: [
      { value: '+200%', label: 'website clicks' },
      { value: '+51.04%', label: 'profile interactions' },
      { value: '+43.38%', label: 'direction requests' },
    ],
    note: "Rankings improved from #3 to #1 for 'ppf mobil' and #6 to #1 for 'pasang ppf mobil' across the monitored 1 km grid, 19 July – 8 August 2024.",
  },
  pillars: [
    {
      title: 'Performance analysis',
      before: 'Reviewed ',
      emphasis: 'keyword performance and local search heatmaps',
      after: ' to identify visibility gaps and guide optimisation priorities.',
    },
    {
      title: 'Client & project delivery',
      before: 'Presented reports, ',
      emphasis: 'translated client feedback into action items',
      after: ', and coordinated delivery with the SEO team.',
    },
    {
      title: 'Account expansion & referrals',
      before: 'Supported ',
      emphasis: 'two closed engagements',
      after: ' through a Gloss Patrol branch expansion and its referral to Garuda Kencana Batik.',
    },
  ],
  articles: {
    title: 'Website articles & press releases',
    description: 'Topic development, keyword research, copywriting, and supporting visuals.',
  },
}

export const about =
  'I work across hospitality marketing, agency project delivery, and financial services content. My scope covers strategy, design, video production, copywriting, paid media, SEO, automation, and reporting.'

export const experience = [
  { role: 'Digital Marketing Executive', company: 'The Grove Suites by Grand Aston', business: 'All-suite hotel · Hospitality', location: 'Jakarta, Indonesia.', period: 'August 2025 – Present', description: 'Integrated campaigns, graphic design, filming, editing, copywriting, paid media, SEO content, automation and reporting.' },
  { role: 'Freelance Digital Marketing & Outreach', company: 'Ghazal’s Silk Flowers Singapore', business: 'Silk flowers & floral arrangements', location: 'Singapore.', period: 'March 2026 – Present', description: 'Social content and digital campaigns across Instagram, TikTok and Facebook, campaign concepts, catalogues and sales collateral, plus B2B outreach to hotels, restaurants and venues.' },
  { role: 'Digital Project Manager', company: 'GetFound (now GTMLab)', business: 'Local SEO & digital marketing agency', location: 'Jakarta, Indonesia.', period: 'July 2024 – October 2024', description: 'Client communication, SEO delivery, keyword and local-search analysis, performance reviews, project coordination and strategy adjustments across 20–30 accounts.' },
  { role: 'SEO Intern', company: 'GetFound (now GTMLab)', business: 'Local SEO & digital marketing agency', location: 'Jakarta, Indonesia.', period: 'March 2024 – July 2024', description: 'Keyword research, SEO writing, Google Business Profile updates, review replies, FAQs, image geotagging, backlink and citation building, and Google Forms for customer-source tracking.' },
  { role: 'Social Media Intern', company: 'Bahana Sekuritas', business: 'Investment banking & securities brokerage', location: 'Jakarta, Indonesia.', period: 'October 2022 – April 2023', description: 'Content planning, copywriting, scriptwriting, directing, filming, editing and on-camera talent for financial-services content.' },
  { role: 'Freelance Project Officer', company: 'HAI Demos / HAI Online, Grid.ID (Kompas Gramedia)', business: 'Youth culture, music & entertainment media', location: 'Jakarta, Indonesia.', period: 'November 2021 – May 2022', description: 'Managed @hai_demos social media and Instagram/WhatsApp inquiries. Recruited musicians for HAI × TuneCore through Facebook communities and personal Twitter outreach; conversion work received recognition from TuneCore’s US headquarters. One outreach tweet recorded 346.3K impressions and 12,284 engagements. Recruited musicians and illustrators for Supermusic band competition and poster submissions.' },
  { role: 'Design, Publication & Branding Staff', company: 'Kakak Asuh Jakarta', business: 'Education & volunteer community', location: 'Jakarta, Indonesia.', period: 'November 2020 – June 2021', description: 'Visual and written content, social media coordination, photography and short-form documentation supporting education and volunteer engagement.' },
  { role: 'Founder & Head of Events', company: 'Kolektif Bising Tenggara', business: 'Independent music & events collective', location: 'Jakarta, Indonesia.', period: 'June 2019 – Present', description: 'Founded the collective in 2019 and was collectively appointed Head of Events. Event coordination, project management, social media and advertising.' },
]

export const education = {
  university: 'Universitas Pembangunan Nasional “Veteran” Jakarta',
  degree: 'Bachelor of Political Science (S.IP.)',
  faculty: 'Faculty of Social and Political Sciences',
  period: '2019 – 2025',
  gpa: '3.50 / 4.00',
  research: 'Football, politics and culture: FC St. Pauli and punk football communities in Indonesia.',
  detail: 'Qualitative research into how communities communicate ideas through media, music, collective activities and independent culture.',
}

export const tools = [
  { group: 'Paid media & discovery', items: ['Meta Ads', 'Meta Business Suite', 'Google Ads', 'Ahrefs', 'Semrush', 'Google Business Profile'] },
  { group: 'Design & video', items: ['Adobe Illustrator', 'Adobe Photoshop', 'Adobe Premiere Pro', 'Canva', 'CapCut'] },
  { group: 'Audio production', items: ['Studio One'] },
  { group: 'Content publishing', items: ['Medium'] },
  { group: 'Automation & reporting', items: ['Make', 'OpenAI', 'Windsor.ai', 'Google Sheets', 'Microsoft Excel', 'ChatGPT'] },
  { group: 'Project management', items: ['Trello'] },
  { group: 'WhatsApp communications', items: ['WATI (WhatsApp Business API)', 'Kouventa (WhatsApp Business API)'] },
]

export const credentials = [
  { issuer: 'Meta', name: 'Marketing Analytics Foundation', date: 'July 2025', kind: 'Course', scope: 'Marketing analytics foundations, measurement and interpreting marketing data.' },
  { issuer: 'HubSpot Academy', name: 'SEO Certification', date: 'April – May 2025', kind: 'Certification', scope: 'Keyword research, on-page SEO, link building and SEO performance reporting.' },
  { issuer: 'MySkill', name: 'Intensive Bootcamp: Digital Marketing', date: 'February – March 2022', kind: 'Bootcamp', scope: 'Digital marketing fundamentals and campaign planning across online channels.' },
  { issuer: '@america Academy × MySkill', name: 'Copywriting Series', date: 'March 2024', kind: 'Event participation', scope: 'Copywriting, audience-focused messaging and promotional communication.' },
]
